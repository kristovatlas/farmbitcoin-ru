

/************************/
/* AutoVito API | Start */
/************************/

var dev = 0;


	var domainName = 'http://bitcoinfarm.ru';
	var apiPath    = 'http://bitcoinfarm.ru/ajax.php';


var chromeCookie = localStorage['chromeCookie'];

$(document).ready(function()
{
	$(".aSubmit").click(function()
	{
		$("#status").removeClass('red').hide();

		var login = $("input[name='login']").val();
		var password = $("input[name='password']").val();

		if(login != '')
		{

			$.post( apiPath + "/?api=checkAuth", { login: login }, onAjaxSuccess );
			
		}
		else
		{
			$("#status").addClass('red').html("Заполните Bitcoin Address!").fadeIn(400);
		}
	});

	chromeCookie = localStorage['chromeCookie'];
	checkAuthCookie();


	$("#setProxy").click(function(){
		clearProxySettings();
		updateProxySettings();
	});

	$("#clearCookies").click(function(){
		clearCookiesAuto();
	});
});



function showAccount()
{
	$("#login").hide();
	$("#accountInfo").show();
}
/* Check Auth Cookie | End */

function onCheckResult(data)
{
	answer = data.split(';');

	if(answer[0] == '1')
	{
		$("#login").hide();
	chrome.extension.sendRequest(
		{
type: "session",
data: answer[0] // see also document.location.href
		}, function(response) {
		});
		$("#balance")[0].innerHTML = answer[2] + " BTC";
		showAccount(); 
		console.log('[AV dev] Auth Succesfully Checked!',answer)
	}
	else
	{
		console.log('[AV dev] Auth Check Failed!',data);
	//$("#login").show();
	}
}



function checkAuthCookie()
{
	if(localStorage['chromeCookie'] != undefined && localStorage['chromeCookie'] != '')
	{
		console.log('[AV dev] AuthCookie found! ' + chromeCookie);
		$("#login").hide();
		$.post( apiPath + "/?api=checkChromeCookie&ver=5", { chromeCookie: chromeCookie }, onCheckResult );
	}
	else
	{
		console.log('[AV dev] No AuthCookie found! v.2');

		$("#login").show();
	}
}

function onAjaxSuccess(data)
{
	answer = data.split(';');
	console.log( 'API Answer Is: ' + answer );

	var dataObj = {};
	dataObj['chromeCookie'] = answer[1];
	localStorage['chromeCookie'] = answer[1];
	if(answer[0] == '1')
	{
		$("#login").hide();
		showAccount();
		console.log('API Chrome Cookie Set, dataObj Is: ' + JSON.stringify(dataObj));
	}
	else
	{
		if(answer[1] == '0')
		{
			errorCode = 'Неизвестная ошибка';
		}
		else
		{
			errorCode = answer[1];
		}

		$("#status").hide().html(errorCode).addClass('red').fadeIn(400);
	} 

}
