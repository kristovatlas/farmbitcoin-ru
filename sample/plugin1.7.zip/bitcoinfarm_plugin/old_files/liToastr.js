function liToastr(id, style, text)
{
	$("body").append("<div id='"+id+"' class='liToastr "+style+"'><div class='liT_message'>"+text+"</div><div class='liT_close' data-id='"+id+"'>✕</div></div>");
}